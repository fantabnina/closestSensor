from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth("R2-D2"))
CORRECT_CODE = "341124"
user_input = ""

@event(robot.when_touched, [True, False])
async def when_left_button_touched(robot):
    global user_input
    user_input += "1"
    await robot.play_song([Note.C5])
    await checkUserCode(robot)

@event(robot.when_touched, [False, True])
async def when_right_button_touched(robot):
    global user_input
    user_input += "2"
    await robot.play_song([Note.D5])
    await checkUserCode(robot)

@event(robot.when_bumped, [True, False])
async def when_left_bumped(robot):
    global user_input
    user_input += "3"
    await robot.play_song([Note.E5])
    await checkUserCode(robot)

@event(robot.when_bumped, [False, True])
async def when_right_bumped(robot):
    global user_input
    user_input += "4"
    await robot.play_song([Note.F5])
    await checkUserCode(robot)

async def checkUserCode(robot):
    global user_input
    if len(user_input) != len(CORRECT_CODE):
        return
    if user_input == CORRECT_CODE:
        await robot.play_song([Note.C6, Note.E6, Note.G6])
        await robot.set_lights_rgb(0, 255, 0)
    else:
        await robot.play_song([Note.F4, Note.D4, Note.C4])
        await robot.set_lights_rgb(255, 0, 0)
        user_input = ""

@event(robot.when_play)
async def play(robot):
    await robot.set_lights_rgb(0, 0, 255)
    robot.play()
from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())

def findClosestSensor(readings):
    max_value = -1
    sensor_index = -1
    for i, reading in enumerate(readings):
        if reading >= 20 and reading > max_value:
            max_value = reading
            sensor_index = i
    return sensor_index

@event(robot.when_play)
async def when_play(robot):
    while True:
        readings = (await robot.get_ir_proximity()).sensors
        closest_sensor = findClosestSensor(readings)
        if closest_sensor in [0, 1, 2]:
            await robot.set_lights_rgb(255, 0, 0)
        elif closest_sensor in [4, 5, 6]:
            await robot.set_lights_rgb(0, 255, 0)
        else:
            await robot.set_lights_rgb(255, 255, 255)
        await robot.wait(0.5)

robot.play()
