from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())
SPEED = 4
ROTATION_DIR = "cw"

@event(robot.when_bumped, [True, False])
async def when_left_bumped(robot):
    global SPEED, ROTATION_DIR
    ROTATION_DIR = "ccw"
    SPEED = 4
    await robot.set_wheel_speeds(-SPEED, SPEED)
    await robot.set_lights_rgb(0, 255, 255)

@event(robot.when_bumped, [False, True])
async def when_right_bumped(robot):
    global SPEED, ROTATION_DIR
    ROTATION_DIR = "cw"
    SPEED = 4
    await robot.set_wheel_speeds(SPEED, -SPEED)
    await robot.set_lights_rgb(255, 0, 255)

@event(robot.when_touched, [True, False])
async def when_dot_button_pressed(robot):
    global SPEED
    SPEED -= 2
    await robot.set_wheel_speeds(SPEED, -SPEED)
    await robot.play_song([Note.C5])

@event(robot.when_touched, [False, True])
async def when_dot_dot_button_pressed(robot):
    global SPEED
    SPEED += 2
    await robot.set_wheel_speeds(SPEED, -SPEED)
    await robot.play_song([Note.D5])

robot.play()
