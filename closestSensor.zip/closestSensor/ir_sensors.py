from irobot_edu_sdk.backend.bluetooth import Bluetooth
from irobot_edu_sdk.robots import event, hand_over, Color, Robot, Root, Create3
from irobot_edu_sdk.music import Note

robot = Create3(Bluetooth())

def findClosestSensor(readings):
    max_value = -1
    sensor_index = -1
    for i, reading in enumerate(readings):
        if reading >= 20 and reading > max_value:
            max_value = reading
            sensor_index = i
    return sensor_index

@event(robot.when_play)
async def when_play(robot):
    while True:
        readings = (await robot.get_ir_proximity()).sensors
        closest_sensor = findClosestSensor(readings)
        if closest_sensor in [0, 1, 2]:
            await robot.set_lights_rgb(255, 0, 0)
        elif closest_sensor in [4, 5, 6]:
            await robot.set_lights_rgb(0, 255, 0)
        else:
            await robot.set_lights_rgb(255, 255, 255)
        await robot.wait(0.5)

robot.play()
